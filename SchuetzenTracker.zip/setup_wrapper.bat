@echo off
echo Lade Gradle Wrapper JAR herunter...
powershell -Command "Invoke-WebRequest -Uri 'https://github.com/gradle/gradle/raw/v8.7.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar'"
if exist "gradle\wrapper\gradle-wrapper.jar" (
    echo Gradle Wrapper JAR erfolgreich heruntergeladen!
    echo Du kannst das Projekt jetzt in Android Studio oeffnen.
) else (
    echo Fehler beim Herunterladen. Bitte manuell downloaden von:
    echo https://github.com/gradle/gradle/raw/v8.7.0/gradle/wrapper/gradle-wrapper.jar
    echo und in gradle\wrapper\ speichern.
)
pause
