package com.schuetzentracker.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.schuetzentracker.model.DetectedShot
import com.schuetzentracker.model.ShotZone
import com.schuetzentracker.model.TargetAnalysisResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiVisionService(private val apiKey: String) {

    private val TAG = "GeminiVision"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)   // Gemini braucht manchmal länger
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    // Gemini 1.5 Flash – kostenlos, gut für Bildanalyse
    private val MODEL = "gemini-1.5-flash"
    private val BASE_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    suspend fun analyzeTarget(
        bitmap: Bitmap,
        discipline: String,
        maxRingsPerShot: Int = 10
    ): Result<TargetAnalysisResult> = withContext(Dispatchers.IO) {
        runCatching {
            // FIX 1: Bild auf max. 1024px verkleinern vor dem Upload
            // Gemini Free Tier: max. ~4MB pro Anfrage. Hochauflösende Fotos
            // können 10–20MB sein und werden abgelehnt oder timeout.
            val resized = resizeBitmap(bitmap, maxSide = 1024)
            val base64Image = bitmapToBase64(resized, quality = 80)

            Log.d(TAG, "Bild-Größe nach Resize: ${resized.width}x${resized.height}")
            Log.d(TAG, "Base64-Länge: ${base64Image.length} Zeichen")
            Log.d(TAG, "API-Key (erste 8 Zeichen): ${apiKey.take(8)}...")

            val prompt = buildPrompt(discipline, maxRingsPerShot)
            val bodyJson = buildRequestBody(base64Image, prompt)

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .addHeader("Content-Type", "application/json")
                .post(bodyJson.toRequestBody("application/json".toMediaType()))
                .build()

            Log.d(TAG, "Sende Anfrage an Gemini API...")

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
                ?: throw Exception("Leere Antwort von Gemini API")

            Log.d(TAG, "HTTP Status: ${response.code}")
            Log.d(TAG, "Antwort (erste 500 Zeichen): ${responseBody.take(500)}")

            if (!response.isSuccessful) {
                val errorMsg = runCatching {
                    gson.fromJson(responseBody, JsonObject::class.java)
                        .getAsJsonObject("error")
                        ?.let { err ->
                            val code = err.get("code")?.asInt
                            val msg = err.get("message")?.asString
                            "Code $code: $msg"
                        }
                }.getOrNull() ?: responseBody.take(300)

                throw Exception(
                    when (response.code) {
                        400 -> "Ungültige Anfrage (400): $errorMsg\n" +
                               "Tipp: API-Key prüfen oder Bild zu groß?"
                        401 -> "API-Key ungültig (401). " +
                               "Bitte in Einstellungen → KI-Analyse einen gültigen Key eintragen."
                        403 -> "Zugriff verweigert (403). " +
                               "Ist die Gemini API für diesen Key aktiviert?"
                        429 -> "Zu viele Anfragen (429). " +
                               "Bitte 1 Minute warten (max. 15 Anfragen/Min kostenlos)."
                        500, 503 -> "Gemini API-Server vorübergehend nicht verfügbar. Erneut versuchen."
                        else -> "Gemini Fehler ${response.code}: $errorMsg"
                    }
                )
            }

            parseGeminiResponse(responseBody, maxRingsPerShot)
        }
    }

    // ────────────────────────────────────────────
    // PROMPT
    // ────────────────────────────────────────────

    private fun buildPrompt(discipline: String, maxRings: Int): String = """
        Du bist ein Experte für Schützensport. Analysiere dieses Foto einer Zielscheibe.
        
        Disziplin: $discipline | Maximale Ringe pro Schuss: $maxRings
        
        Aufgabe:
        1. Erkenne ALLE Schusslöcher (kreisrunde Einschläge/Risse im Papier)
        2. Bestimme den Ringwert jedes Treffers (0 bis $maxRings)
           - Ein Treffer gilt für den HÖHEREN Ring wenn er die Linie berührt
        3. Erkenne Schusspflaster (weiße/helle Rechtecke oder Kreise die Löcher abdecken)
           - Schätze den Ringwert UNTER dem Pflaster
        4. Beurteile wo das Trefferbild liegt
        
        Antworte NUR mit diesem JSON (kein Text davor/danach, keine ```-Blöcke):
        {
          "shots": [
            { "x": 0.5, "y": 0.5, "rings": 9, "is_patch": false, "confidence": 0.9 }
          ],
          "total_rings": 90,
          "shot_count": 10,
          "patches_count": 0,
          "patch_rings": 0,
          "group_center": "INNER",
          "overall_confidence": 0.85,
          "notes": "Kurze Beschreibung"
        }
        
        Regeln:
        - group_center: BULL (Schwarze Mitte), INNER (Innerer Bereich), MIDDLE, OUTER, MISS, UNKNOWN
        - x und y: relative Position auf der Scheibe, 0.0=links/oben, 1.0=rechts/unten
        - confidence: 0.0 bis 1.0 (wie sicher bist du bei diesem Treffer)
        - Wenn keine Treffer erkennbar: shot_count=0, total_rings=0
    """.trimIndent()

    // ────────────────────────────────────────────
    // REQUEST BODY
    // FIX 2: responseMimeType entfernt – das störte die JSON-Ausgabe
    // ────────────────────────────────────────────

    private fun buildRequestBody(base64Image: String, prompt: String): String {
        // Prompt als JSON-String escapen
        val promptJson = gson.toJson(prompt)

        return """
        {
          "contents": [
            {
              "parts": [
                {
                  "inline_data": {
                    "mime_type": "image/jpeg",
                    "data": "$base64Image"
                  }
                },
                {
                  "text": $promptJson
                }
              ]
            }
          ],
          "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": 2048
          }
        }
        """.trimIndent()
    }

    // ────────────────────────────────────────────
    // RESPONSE PARSING
    // ────────────────────────────────────────────

    private fun parseGeminiResponse(responseBody: String, maxRings: Int): TargetAnalysisResult {
        val root = gson.fromJson(responseBody, JsonObject::class.java)

        // Prüfe auf blockierte Antwort (Safety Filter)
        val blockReason = root.getAsJsonArray("candidates")
            ?.get(0)?.asJsonObject
            ?.get("finishReason")?.asString

        if (blockReason == "SAFETY" || blockReason == "RECITATION") {
            throw Exception("Gemini hat die Analyse abgelehnt (Safety Filter). Versuche ein anderes Bild.")
        }

        val textContent = root
            .getAsJsonArray("candidates")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("content")
            ?.getAsJsonArray("parts")
            ?.get(0)?.asJsonObject
            ?.get("text")?.asString
            ?: throw Exception(
                "Keine Textantwort von Gemini erhalten.\n" +
                "Vollständige Antwort: ${responseBody.take(500)}"
            )

        Log.d(TAG, "Gemini Antwort-Text: $textContent")

        val jsonString = extractJson(textContent)
        val analysis = gson.fromJson(jsonString, JsonObject::class.java)

        val shots = analysis.getAsJsonArray("shots")?.map { el ->
            val s = el.asJsonObject
            DetectedShot(
                x          = runCatching { s.get("x").asFloat }.getOrDefault(0.5f),
                y          = runCatching { s.get("y").asFloat }.getOrDefault(0.5f),
                rings      = runCatching { s.get("rings").asInt }.getOrDefault(0).coerceIn(0, maxRings),
                isPatch    = runCatching { s.get("is_patch").asBoolean }.getOrDefault(false),
                confidence = runCatching { s.get("confidence").asFloat }.getOrDefault(0.8f)
            )
        } ?: emptyList()

        val groupCenterStr = runCatching { analysis.get("group_center").asString }.getOrDefault("UNKNOWN")
        val groupCenter = runCatching { ShotZone.valueOf(groupCenterStr) }.getOrDefault(ShotZone.UNKNOWN)

        return TargetAnalysisResult(
            detectedRings   = shots,
            totalRings      = runCatching { analysis.get("total_rings").asInt }.getOrDefault(shots.sumOf { it.rings }),
            shotCount       = runCatching { analysis.get("shot_count").asInt }.getOrDefault(shots.size),
            patchesDetected = runCatching { analysis.get("patches_count").asInt }.getOrDefault(0),
            patchRings      = runCatching { analysis.get("patch_rings").asInt }.getOrDefault(0),
            groupSize       = null,
            groupCenter     = groupCenter,
            confidence      = runCatching { analysis.get("overall_confidence").asFloat }.getOrDefault(0.7f),
            rawApiResponse  = textContent
        )
    }

    private fun extractJson(text: String): String {
        val cleaned = text
            .replace("```json", "")
            .replace("```", "")
            .trim()
        val start = cleaned.indexOf('{')
        val end   = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw Exception(
                "Gemini hat kein gültiges JSON zurückgegeben.\n" +
                "Antwort: ${text.take(300)}"
            )
        }
        return cleaned.substring(start, end + 1)
    }

    // ────────────────────────────────────────────
    // BILD-HILFSFUNKTIONEN
    // ────────────────────────────────────────────

    /**
     * Verkleinert das Bild auf maxSide × maxSide Pixel (behält Seitenverhältnis).
     * Wichtig: Gemini Free Tier limitiert die Anfragegröße.
     * Ein 4000×3000-Foto wird auf 1024×768 verkleinert = ~10x kleiner.
     */
    private fun resizeBitmap(bitmap: Bitmap, maxSide: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxSide && h <= maxSide) return bitmap  // Kein Resize nötig

        val ratio = maxSide.toFloat() / maxOf(w, h)
        val newW = (w * ratio).toInt()
        val newH = (h * ratio).toInt()
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun bitmapToBase64(bitmap: Bitmap, quality: Int = 80): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
