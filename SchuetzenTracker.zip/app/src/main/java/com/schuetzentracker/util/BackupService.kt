package com.schuetzentracker.util

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializer
import com.google.gson.JsonSerializer
import com.schuetzentracker.data.database.AppDatabase
import com.schuetzentracker.data.database.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject

// ────────────────────────────────────────────────
// BACKUP SERVICE
//
// Export: Alle Trainings, Serien, Schüsse, Disziplinen
//         als JSON-Datei in Downloads
//
// Import: JSON-Datei einlesen und in DB schreiben
//         (vorhandene Daten werden behalten, Duplikate ignoriert)
// ────────────────────────────────────────────────

class BackupService @Inject constructor(
    private val context: Context
) {
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    // ── EXPORT ──────────────────────────────────────────────────────

    suspend fun exportToDownloads(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val db = AppDatabase.create(context)

            // Alle Daten aus DB lesen
            val disciplines = db.disciplineDao().getAll().first()
            val sessions    = db.trainingSessionDao().getAllWithSeries().first()
            val goals       = db.trainingGoalDao().getAll().first()
            val achievements = db.achievementDao().getAll().first()

            // Backup-Objekt erstellen
            val backup = BackupData(
                version       = 1,
                exportDate    = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                disciplines   = disciplines,
                sessions      = sessions.map { it.session },
                series        = sessions.flatMap { s -> s.series.map { it.series } },
                shots         = sessions.flatMap { s -> s.series.flatMap { sr -> sr.shots } },
                goals         = goals,
                achievements  = achievements
            )

            val json = gson.toJson(backup)

            // In Downloads-Ordner speichern
            val filename = "SchuetzenTracker_Backup_${
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
            }.json"

            val file = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                filename
            )

            file.writeText(json, Charsets.UTF_8)
            file.absolutePath
        }
    }

    // Alternativ: In App-internen Speicher (kein Schreibrecht nötig)
    suspend fun exportToAppFiles(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val db = AppDatabase.create(context)
            val disciplines = db.disciplineDao().getAll().first()
            val sessions    = db.trainingSessionDao().getAllWithSeries().first()
            val goals       = db.trainingGoalDao().getAll().first()
            val achievements = db.achievementDao().getAll().first()

            val backup = BackupData(
                version       = 1,
                exportDate    = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                disciplines   = disciplines,
                sessions      = sessions.map { it.session },
                series        = sessions.flatMap { s -> s.series.map { it.series } },
                shots         = sessions.flatMap { s -> s.series.flatMap { sr -> sr.shots } },
                goals         = goals,
                achievements  = achievements
            )

            val json = gson.toJson(backup)

            val filename = "backup_${
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
            }.json"

            val file = File(context.filesDir, filename)
            file.writeText(json, Charsets.UTF_8)
            file.absolutePath
        }
    }

    // ── IMPORT ──────────────────────────────────────────────────────

    suspend fun importFromUri(uri: Uri): Result<ImportStats> = withContext(Dispatchers.IO) {
        runCatching {
            val json = context.contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
                ?: throw Exception("Datei konnte nicht gelesen werden.")

            val backup = gson.fromJson(json, BackupData::class.java)
                ?: throw Exception("Ungültiges Backup-Format.")

            val db = AppDatabase.create(context)
            var disciplinesImported = 0
            var sessionsImported    = 0
            var shotsImported       = 0

            // Disziplinen importieren (INSERT OR IGNORE)
            backup.disciplines?.forEach { d ->
                db.disciplineDao().insert(d.copy(id = 0)) // neue ID vergeben
                disciplinesImported++
            }

            // Sessions importieren
            backup.sessions?.forEach { session ->
                val newSessionId = db.trainingSessionDao().insert(session.copy(id = 0))

                // Serien dieser Session finden und importieren
                val sessionSeries = backup.series?.filter { it.sessionId == session.id } ?: emptyList()
                sessionSeries.forEach { series ->
                    val newSeriesId = db.seriesDao().insert(series.copy(id = 0, sessionId = newSessionId))

                    // Schüsse dieser Serie importieren
                    val seriesShots = backup.shots?.filter { it.seriesId == series.id } ?: emptyList()
                    seriesShots.forEach { shot ->
                        db.shotDao().insert(shot.copy(id = 0, seriesId = newSeriesId))
                        shotsImported++
                    }
                }
                sessionsImported++
            }

            ImportStats(
                disciplinesImported = disciplinesImported,
                sessionsImported    = sessionsImported,
                shotsImported       = shotsImported
            )
        }
    }
}

// ── Backup-Datenstruktur ──────────────────────────────────────────────────

data class BackupData(
    val version: Int = 1,
    val exportDate: String = "",
    val disciplines: List<DisciplineEntity>? = null,
    val sessions: List<TrainingSessionEntity>? = null,
    val series: List<SeriesEntity>? = null,
    val shots: List<ShotEntity>? = null,
    val goals: List<TrainingGoalEntity>? = null,
    val achievements: List<AchievementEntity>? = null
)

data class ImportStats(
    val disciplinesImported: Int,
    val sessionsImported: Int,
    val shotsImported: Int
)
