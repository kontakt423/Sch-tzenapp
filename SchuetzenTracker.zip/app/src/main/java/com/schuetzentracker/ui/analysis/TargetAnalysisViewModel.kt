package com.schuetzentracker.ui.analysis

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.schuetzentracker.data.repository.TrainingRepository
import com.schuetzentracker.model.TargetAnalysisResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TargetAnalysisViewModel @Inject constructor(
    private val repository: TrainingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TargetAnalysisUiState())
    val uiState: StateFlow<TargetAnalysisUiState> = _uiState.asStateFlow()

    private var currentSeriesId: Long = 0L

    fun load(seriesId: Long) {
        currentSeriesId = seriesId
        viewModelScope.launch {
            val session = repository.getSession(seriesId)
            val series = session?.series?.find { it.id == seriesId }
            _uiState.update { state ->
                state.copy(
                    imagePath = series?.targetImagePath,
                    result = series?.analysisResult,
                    maxRingsPerShot = session?.disciplineModel?.maxRingsPerShot ?: 10,
                    isAnalyzing = false
                )
            }
        }
    }

    fun retry() {
        _uiState.update { it.copy(error = null, isAnalyzing = true) }
        load(currentSeriesId)
    }

    fun applyResultToShots() {
        // Ergebnis übernehmen – wird über NavBackStack an NewTrainingScreen zurückgegeben
    }
}

data class TargetAnalysisUiState(
    val isAnalyzing: Boolean = false,
    val result: TargetAnalysisResult? = null,
    val imagePath: String? = null,
    val maxRingsPerShot: Int = 10,
    val error: String? = null
)
