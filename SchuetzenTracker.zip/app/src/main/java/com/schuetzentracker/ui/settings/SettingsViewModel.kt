package com.schuetzentracker.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.schuetzentracker.api.ApiProvider
import com.schuetzentracker.api.ClaudeVisionService
import com.schuetzentracker.api.GeminiVisionService
import com.schuetzentracker.api.TargetAnalysisService
import com.schuetzentracker.data.repository.UserPreferencesRepository
import com.schuetzentracker.util.ReminderManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefsRepo: UserPreferencesRepository,
    private val analysisService: TargetAnalysisService,
    workManager: WorkManager
) : ViewModel() {

    private val reminderManager = ReminderManager(workManager)

    val uiState: StateFlow<SettingsUiState> = prefsRepo.userPreferences
        .map { prefs ->
            SettingsUiState(
                shooterName          = prefs.shooterName,
                clubName             = prefs.clubName,
                memberNumber         = prefs.memberNumber,
                defaultLocation      = prefs.defaultLocation,
                dailyReminderEnabled = prefs.dailyReminderEnabled,
                reminderHour         = prefs.reminderHour,
                geminiApiKey         = prefs.geminiApiKey,
                claudeApiKey         = prefs.claudeApiKey,
                selectedProvider     = prefs.apiProvider
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SettingsUiState()
        )

    init {
        // Beim Start: gespeicherte Keys in Service laden
        viewModelScope.launch {
            prefsRepo.userPreferences.first().let { prefs ->
                applyKeys(prefs.geminiApiKey, prefs.claudeApiKey, prefs.apiProvider)
            }
        }
    }

    fun updateName(v: String)            = save { prefsRepo.updateShooterName(v) }
    fun updateClubName(v: String)        = save { prefsRepo.updateClubName(v) }
    fun updateMemberNumber(v: String)    = save { prefsRepo.updateMemberNumber(v) }
    fun updateDefaultLocation(v: String) = save { prefsRepo.updateDefaultLocation(v) }

    fun updateGeminiApiKey(key: String) = save {
        prefsRepo.updateGeminiApiKey(key)
        applyKeys(key, uiState.value.claudeApiKey, uiState.value.selectedProvider)
    }

    fun updateClaudeApiKey(key: String) = save {
        prefsRepo.updateClaudeApiKey(key)
        applyKeys(uiState.value.geminiApiKey, key, uiState.value.selectedProvider)
    }

    fun selectProvider(provider: ApiProvider) = save {
        prefsRepo.updateApiProvider(provider)
        applyKeys(uiState.value.geminiApiKey, uiState.value.claudeApiKey, provider)
    }

    fun toggleDailyReminder(enabled: Boolean) = save {
        prefsRepo.updateDailyReminder(enabled)
        if (enabled) reminderManager.scheduleDailyReminder(uiState.value.reminderHour)
        else reminderManager.cancelAll()
    }

    fun setReminderHour(hour: Int) = save {
        prefsRepo.updateReminderHour(hour)
        if (uiState.value.dailyReminderEnabled) reminderManager.scheduleDailyReminder(hour)
    }

    fun exportData() = save { /* TODO */ }
    fun importData() = save { /* TODO */ }

    private fun applyKeys(geminiKey: String, claudeKey: String, provider: ApiProvider) {
        analysisService.updateServices(
            gemini = if (geminiKey.isNotBlank()) GeminiVisionService(geminiKey) else null,
            claude = if (claudeKey.isNotBlank()) ClaudeVisionService(claudeKey) else null,
            provider = provider
        )
    }

    private fun save(block: suspend () -> Unit) = viewModelScope.launch { block() }
}

data class SettingsUiState(
    val shooterName: String = "",
    val clubName: String = "",
    val memberNumber: String = "",
    val defaultLocation: String = "Schießstand",
    val dailyReminderEnabled: Boolean = false,
    val reminderHour: Int = 18,
    val geminiApiKey: String = "",
    val claudeApiKey: String = "",
    val selectedProvider: ApiProvider = ApiProvider.GEMINI
)
