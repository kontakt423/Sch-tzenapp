package com.schuetzentracker.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.schuetzentracker.data.repository.UserPreferencesRepository
import com.schuetzentracker.util.BackupService
import com.schuetzentracker.util.ReminderManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefsRepo: UserPreferencesRepository,
    private val backupService: BackupService,
    workManager: WorkManager
) : ViewModel() {

    private val reminderManager = ReminderManager(workManager)

    private val _shooterName          = MutableStateFlow("")
    private val _clubName             = MutableStateFlow("")
    private val _memberNumber         = MutableStateFlow("")
    private val _defaultLocation      = MutableStateFlow("Schießstand")
    private val _dailyReminderEnabled = MutableStateFlow(false)
    private val _reminderHour         = MutableStateFlow(18)
    private val _backupMessage        = MutableStateFlow<String?>(null)

    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    val uiState: StateFlow<SettingsUiState> = combine(
        _shooterName, _clubName, _memberNumber, _defaultLocation,
        _dailyReminderEnabled
    ) { name, club, member, location, reminder ->
        SettingsUiState(
            shooterName = name, clubName = club,
            memberNumber = member, defaultLocation = location,
            dailyReminderEnabled = reminder
        )
    }.combine(_reminderHour) { base, hour ->
        base.copy(reminderHour = hour)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    init {
        viewModelScope.launch {
            val prefs = prefsRepo.userPreferences.first()
            _shooterName.value          = prefs.shooterName
            _clubName.value             = prefs.clubName
            _memberNumber.value         = prefs.memberNumber
            _defaultLocation.value      = prefs.defaultLocation
            _dailyReminderEnabled.value = prefs.dailyReminderEnabled
            _reminderHour.value         = prefs.reminderHour
        }
        setupDebounce()
    }

    @OptIn(FlowPreview::class)
    private fun setupDebounce() {
        viewModelScope.launch { _shooterName.debounce(800).drop(1).collect { prefsRepo.updateShooterName(it) } }
        viewModelScope.launch { _clubName.debounce(800).drop(1).collect { prefsRepo.updateClubName(it) } }
        viewModelScope.launch { _memberNumber.debounce(800).drop(1).collect { prefsRepo.updateMemberNumber(it) } }
        viewModelScope.launch { _defaultLocation.debounce(800).drop(1).collect { prefsRepo.updateDefaultLocation(it) } }
    }

    fun updateName(v: String)            { _shooterName.value = v }
    fun updateClubName(v: String)        { _clubName.value = v }
    fun updateMemberNumber(v: String)    { _memberNumber.value = v }
    fun updateDefaultLocation(v: String) { _defaultLocation.value = v }

    fun toggleDailyReminder(enabled: Boolean) {
        _dailyReminderEnabled.value = enabled
        viewModelScope.launch {
            prefsRepo.updateDailyReminder(enabled)
            if (enabled) reminderManager.scheduleDailyReminder(_reminderHour.value)
            else reminderManager.cancelAll()
        }
    }

    fun setReminderHour(hour: Int) {
        _reminderHour.value = hour
        viewModelScope.launch {
            prefsRepo.updateReminderHour(hour)
            if (_dailyReminderEnabled.value) reminderManager.scheduleDailyReminder(hour)
        }
    }

    fun exportData() {
        viewModelScope.launch {
            _backupMessage.value = "⏳ Exportiere Daten..."
            backupService.exportToAppFiles()
                .onSuccess { path -> _backupMessage.value = "✅ Backup gespeichert:\n$path" }
                .onFailure { e  -> _backupMessage.value  = "❌ Export fehlgeschlagen: ${e.message}" }
        }
    }

    fun importData(uri: Uri) {
        viewModelScope.launch {
            _backupMessage.value = "⏳ Importiere Backup..."
            backupService.importFromUri(uri)
                .onSuccess { stats ->
                    _backupMessage.value = "✅ Import erfolgreich:\n" +
                        "${stats.disciplinesImported} Disziplinen, " +
                        "${stats.sessionsImported} Trainings importiert."
                }
                .onFailure { e -> _backupMessage.value = "❌ Import fehlgeschlagen: ${e.message}" }
        }
    }

    fun clearBackupMessage() { _backupMessage.value = null }
}

data class SettingsUiState(
    val shooterName: String = "",
    val clubName: String = "",
    val memberNumber: String = "",
    val defaultLocation: String = "Schießstand",
    val dailyReminderEnabled: Boolean = false,
    val reminderHour: Int = 18
)
