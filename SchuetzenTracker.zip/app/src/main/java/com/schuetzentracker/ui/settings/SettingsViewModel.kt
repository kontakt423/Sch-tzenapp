package com.schuetzentracker.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.schuetzentracker.api.ApiProvider
import com.schuetzentracker.api.ClaudeVisionService
import com.schuetzentracker.api.GeminiVisionService
import com.schuetzentracker.api.TargetAnalysisService
import com.schuetzentracker.data.repository.UserPreferencesRepository
import com.schuetzentracker.util.ReminderManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ────────────────────────────────────────────────
// SETTINGS VIEW MODEL
//
// FIX "Jumping Cursor":
// Der uiState wird NICHT direkt aus dem DataStore abgeleitet.
// Stattdessen gibt es lokale MutableStateFlows für Texteingaben.
// DataStore wird nur beim expliziten Speichern (onNameSaved etc.)
// oder mit Debounce (nach 800ms Tippstop) geschrieben.
// Das verhindert die Recomposition-Schleife, die den Cursor
// an den Anfang springt.
// ────────────────────────────────────────────────

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefsRepo: UserPreferencesRepository,
    private val analysisService: TargetAnalysisService,
    workManager: WorkManager
) : ViewModel() {

    private val reminderManager = ReminderManager(workManager)

    // ── LOKALE STATE (kein DataStore-Roundtrip) ──────────────────────
    // Diese Flows werden sofort aktualisiert wenn der User tippt.
    // Die Werte kommen initial aus dem DataStore (einmalig beim Start).

    private val _shooterName    = MutableStateFlow("")
    private val _clubName       = MutableStateFlow("")
    private val _memberNumber   = MutableStateFlow("")
    private val _defaultLocation= MutableStateFlow("Schießstand")
    private val _geminiApiKey   = MutableStateFlow("")
    private val _claudeApiKey   = MutableStateFlow("")
    private val _selectedProvider   = MutableStateFlow(ApiProvider.GEMINI)
    private val _dailyReminderEnabled = MutableStateFlow(false)
    private val _reminderHour   = MutableStateFlow(18)

    // ── UI STATE (kombiniert alle lokalen Flows) ─────────────────────
    val uiState: StateFlow<SettingsUiState> = combine(
        _shooterName, _clubName, _memberNumber, _defaultLocation, _geminiApiKey
    ) { name, club, member, location, gemini ->
        SettingsUiState(
            shooterName = name,
            clubName = club,
            memberNumber = member,
            defaultLocation = location,
            geminiApiKey = gemini
        )
    }.combine(
        combine(_claudeApiKey, _selectedProvider, _dailyReminderEnabled, _reminderHour) {
            claude, provider, reminder, hour ->
            PartialState(claude, provider, reminder, hour)
        }
    ) { base, partial ->
        base.copy(
            claudeApiKey = partial.claudeApiKey,
            selectedProvider = partial.selectedProvider,
            dailyReminderEnabled = partial.dailyReminderEnabled,
            reminderHour = partial.reminderHour
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    init {
        // Einmalig beim Start: Werte aus DataStore in lokale Flows laden
        viewModelScope.launch {
            val prefs = prefsRepo.userPreferences.first()
            _shooterName.value     = prefs.shooterName
            _clubName.value        = prefs.clubName
            _memberNumber.value    = prefs.memberNumber
            _defaultLocation.value = prefs.defaultLocation
            _geminiApiKey.value    = prefs.geminiApiKey
            _claudeApiKey.value    = prefs.claudeApiKey
            _selectedProvider.value = prefs.apiProvider
            _dailyReminderEnabled.value = prefs.dailyReminderEnabled
            _reminderHour.value    = prefs.reminderHour

            // API-Service mit gespeicherten Keys initialisieren
            applyKeys(prefs.geminiApiKey, prefs.claudeApiKey, prefs.apiProvider)
        }

        // Debounce: Namen etc. erst nach 800ms Tippstop in DataStore speichern
        setupDebounce()
    }

    @OptIn(FlowPreview::class)
    private fun setupDebounce() {
        viewModelScope.launch {
            _shooterName.debounce(800).drop(1).collect { prefsRepo.updateShooterName(it) }
        }
        viewModelScope.launch {
            _clubName.debounce(800).drop(1).collect { prefsRepo.updateClubName(it) }
        }
        viewModelScope.launch {
            _memberNumber.debounce(800).drop(1).collect { prefsRepo.updateMemberNumber(it) }
        }
        viewModelScope.launch {
            _defaultLocation.debounce(800).drop(1).collect { prefsRepo.updateDefaultLocation(it) }
        }
    }

    // ── TEXTEINGABE: Lokalen Flow sofort aktualisieren (kein DB-Roundtrip) ─

    /** Wird bei jedem Tastendruck aufgerufen – kein DB-Schreiben hier */
    fun updateName(v: String)            { _shooterName.value = v }
    fun updateClubName(v: String)        { _clubName.value = v }
    fun updateMemberNumber(v: String)    { _memberNumber.value = v }
    fun updateDefaultLocation(v: String) { _defaultLocation.value = v }

    // ── API KEYS: Sofort speichern bei explizitem Speichern-Button ────

    fun updateGeminiApiKey(key: String) {
        _geminiApiKey.value = key
        viewModelScope.launch {
            prefsRepo.updateGeminiApiKey(key)
            applyKeys(key, _claudeApiKey.value, _selectedProvider.value)
        }
    }

    fun updateClaudeApiKey(key: String) {
        _claudeApiKey.value = key
        viewModelScope.launch {
            prefsRepo.updateClaudeApiKey(key)
            applyKeys(_geminiApiKey.value, key, _selectedProvider.value)
        }
    }

    fun selectProvider(provider: ApiProvider) {
        _selectedProvider.value = provider
        viewModelScope.launch {
            prefsRepo.updateApiProvider(provider)
            applyKeys(_geminiApiKey.value, _claudeApiKey.value, provider)
        }
    }

    // ── ERINNERUNGEN ────────────────────────────────────────────────

    fun toggleDailyReminder(enabled: Boolean) {
        _dailyReminderEnabled.value = enabled
        viewModelScope.launch {
            prefsRepo.updateDailyReminder(enabled)
            if (enabled) reminderManager.scheduleDailyReminder(_reminderHour.value)
            else reminderManager.cancelAll()
        }
    }

    fun setReminderHour(hour: Int) {
        _reminderHour.value = hour
        viewModelScope.launch {
            prefsRepo.updateReminderHour(hour)
            if (_dailyReminderEnabled.value) reminderManager.scheduleDailyReminder(hour)
        }
    }

    // ── DATEN ────────────────────────────────────────────────────────

    fun exportData() { /* TODO */ }
    fun importData() { /* TODO */ }

    // ── INTERN ───────────────────────────────────────────────────────

    private fun applyKeys(geminiKey: String, claudeKey: String, provider: ApiProvider) {
        analysisService.updateServices(
            gemini   = if (geminiKey.isNotBlank()) GeminiVisionService(geminiKey) else null,
            claude   = if (claudeKey.isNotBlank()) ClaudeVisionService(claudeKey) else null,
            provider = provider
        )
    }
}

// Helper für combine()
private data class PartialState(
    val claudeApiKey: String,
    val selectedProvider: ApiProvider,
    val dailyReminderEnabled: Boolean,
    val reminderHour: Int
)

data class SettingsUiState(
    val shooterName: String = "",
    val clubName: String = "",
    val memberNumber: String = "",
    val defaultLocation: String = "Schießstand",
    val dailyReminderEnabled: Boolean = false,
    val reminderHour: Int = 18,
    val geminiApiKey: String = "",
    val claudeApiKey: String = "",
    val selectedProvider: ApiProvider = ApiProvider.GEMINI
)
