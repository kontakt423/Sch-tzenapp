package com.schuetzentracker.ui.settings

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

// ────────────────────────────────────────────────
// OPTIONS / EINSTELLUNGEN SCREEN
// mit dediziertem KI-Analyse-Tab
// ────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val tabs = listOf("👤 Profil", "🔔 Erinnerungen", "📂 Daten")
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Optionen") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp
            ) {
                tabs.forEachIndexed { i, title ->
                    Tab(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        text = { Text(title, style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }

            when (selectedTab) {
                0 -> ProfileTab(uiState, viewModel)
                1 -> RemindersTab(uiState, viewModel)
                2 -> DataTab(viewModel)
            }
        }
    }
}


// ────────────────────────────────────────────────
// TAB 2: PROFIL
// ────────────────────────────────────────────────

@Composable
fun ProfileTab(state: SettingsUiState, vm: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Schützenprofil", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = state.shooterName,
            onValueChange = vm::updateName,
            label = { Text("Dein Name") },
            leadingIcon = { Icon(Icons.Default.Person, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.clubName,
            onValueChange = vm::updateClubName,
            label = { Text("Verein") },
            leadingIcon = { Icon(Icons.Default.Groups, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.memberNumber,
            onValueChange = vm::updateMemberNumber,
            label = { Text("Mitgliedsnummer") },
            leadingIcon = { Icon(Icons.Default.Badge, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.defaultLocation,
            onValueChange = vm::updateDefaultLocation,
            label = { Text("Standard-Schießstand") },
            leadingIcon = { Icon(Icons.Default.LocationOn, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
    }
}

// ────────────────────────────────────────────────
// TAB 3: ERINNERUNGEN
// ────────────────────────────────────────────────

@Composable
fun RemindersTab(state: SettingsUiState, vm: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Training-Erinnerungen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Card {
            ListItem(
                headlineContent = { Text("Tägliche Erinnerung") },
                supportingContent = {
                    Text(
                        if (state.dailyReminderEnabled)
                            "Aktiv – täglich um ${state.reminderHour}:00 Uhr"
                        else "Deaktiviert"
                    )
                },
                trailingContent = {
                    Switch(
                        checked = state.dailyReminderEnabled,
                        onCheckedChange = vm::toggleDailyReminder
                    )
                },
                leadingContent = { Icon(Icons.Default.Notifications, null) }
            )
        }

        AnimatedVisibility(visible = state.dailyReminderEnabled) {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Uhrzeit: ${state.reminderHour}:00 Uhr",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = state.reminderHour.toFloat(),
                        onValueChange = { vm.setReminderHour(it.toInt()) },
                        valueRange = 6f..22f,
                        steps = 15,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("6:00", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("22:00", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ────────────────────────────────────────────────
// TAB 4: DATEN
// ────────────────────────────────────────────────

@Composable
fun DataTab(vm: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Daten & Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Card {
            ListItem(
                headlineContent = { Text("Trainings exportieren") },
                supportingContent = { Text("Alle Daten als JSON-Backup speichern") },
                leadingContent = { Icon(Icons.Default.FileDownload, null) },
                modifier = Modifier.clickable { vm.exportData() }
            )
        }
        Card {
            ListItem(
                headlineContent = { Text("Backup importieren") },
                supportingContent = { Text("JSON-Backup wiederherstellen") },
                leadingContent = { Icon(Icons.Default.FileUpload, null) },
                modifier = Modifier.clickable { vm.importData() }
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "SchützenTracker v1.0.0\nKI-Analyse mit Google Gemini (kostenlos) oder Anthropic Claude",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
