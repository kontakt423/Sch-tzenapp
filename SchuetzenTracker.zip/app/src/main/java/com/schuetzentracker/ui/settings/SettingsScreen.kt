package com.schuetzentracker.ui.settings

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.hilt.navigation.compose.hiltViewModel

// ────────────────────────────────────────────────
// OPTIONS / EINSTELLUNGEN SCREEN
// mit dediziertem KI-Analyse-Tab
// ────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val tabs = listOf("👤 Profil", "🔔 Erinnerungen", "📂 Daten")
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Optionen") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp
            ) {
                tabs.forEachIndexed { i, title ->
                    Tab(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        text = { Text(title, style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }

            when (selectedTab) {
                0 -> ProfileTab(uiState, viewModel)
                1 -> RemindersTab(uiState, viewModel)
                2 -> DataTab(viewModel)
            }
        }
    }
}


// ────────────────────────────────────────────────
// TAB 2: PROFIL
// ────────────────────────────────────────────────

@Composable
fun ProfileTab(state: SettingsUiState, vm: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Schützenprofil", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = state.shooterName,
            onValueChange = vm::updateName,
            label = { Text("Dein Name") },
            leadingIcon = { Icon(Icons.Default.Person, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.clubName,
            onValueChange = vm::updateClubName,
            label = { Text("Verein") },
            leadingIcon = { Icon(Icons.Default.Groups, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.memberNumber,
            onValueChange = vm::updateMemberNumber,
            label = { Text("Mitgliedsnummer") },
            leadingIcon = { Icon(Icons.Default.Badge, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        OutlinedTextField(
            value = state.defaultLocation,
            onValueChange = vm::updateDefaultLocation,
            label = { Text("Standard-Schießstand") },
            leadingIcon = { Icon(Icons.Default.LocationOn, null) },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
    }
}

// ────────────────────────────────────────────────
// TAB 3: ERINNERUNGEN
// ────────────────────────────────────────────────

@Composable
fun RemindersTab(state: SettingsUiState, vm: SettingsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Training-Erinnerungen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Card {
            ListItem(
                headlineContent = { Text("Tägliche Erinnerung") },
                supportingContent = {
                    Text(
                        if (state.dailyReminderEnabled)
                            "Aktiv – täglich um ${state.reminderHour}:00 Uhr"
                        else "Deaktiviert"
                    )
                },
                trailingContent = {
                    Switch(
                        checked = state.dailyReminderEnabled,
                        onCheckedChange = vm::toggleDailyReminder
                    )
                },
                leadingContent = { Icon(Icons.Default.Notifications, null) }
            )
        }

        AnimatedVisibility(visible = state.dailyReminderEnabled) {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Uhrzeit: ${state.reminderHour}:00 Uhr",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = state.reminderHour.toFloat(),
                        onValueChange = { vm.setReminderHour(it.toInt()) },
                        valueRange = 6f..22f,
                        steps = 15,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("6:00", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("22:00", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ────────────────────────────────────────────────
// TAB 4: DATEN
// ────────────────────────────────────────────────

@Composable
fun DataTab(vm: SettingsViewModel) {
    val backupMessage by vm.backupMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? -> uri?.let { vm.importData(it) } }

    LaunchedEffect(backupMessage) {
        backupMessage?.let { msg ->
            snackbarHostState.showSnackbar(message = msg, duration = SnackbarDuration.Long)
            vm.clearBackupMessage()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Daten & Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.FileDownload, null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text("Trainings exportieren", fontWeight = FontWeight.Medium)
                            Text("Alle Daten als JSON sichern", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Button(onClick = { vm.exportData() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FileDownload, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp)); Text("Backup erstellen")
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.FileUpload, null, tint = MaterialTheme.colorScheme.secondary)
                        Column {
                            Text("Backup importieren", fontWeight = FontWeight.Medium)
                            Text("JSON-Backup wiederherstellen", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    OutlinedButton(onClick = { importLauncher.launch("application/json") },
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FileUpload, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp)); Text("JSON-Datei auswählen")
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("SchützenTracker v1.0.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        SnackbarHost(snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
