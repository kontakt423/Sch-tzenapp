package com.schuetzentracker.ui.training

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.schuetzentracker.data.repository.DisciplineRepository
import com.schuetzentracker.data.repository.TrainingRepository
import com.schuetzentracker.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

@HiltViewModel
class NewTrainingViewModel @Inject constructor(
    private val trainingRepo: TrainingRepository,
    private val disciplineRepo: DisciplineRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(NewTrainingUiState())
    val uiState: StateFlow<NewTrainingUiState> = _uiState.asStateFlow()

    private var analysisSeriesIndex = 0

    init {
        viewModelScope.launch {
            disciplineRepo.getAll().collect { disciplines ->
                _uiState.update { state ->
                    state.copy(
                        availableDisciplines = disciplines,
                        selectedDiscipline = state.selectedDiscipline ?: disciplines.firstOrNull()
                    )
                }
            }
        }
    }

    // ── Mode & Discipline ────────────────────────────────────────────

    fun selectMode(mode: TrainingMode) = _uiState.update { it.copy(selectedMode = mode) }

    fun selectDiscipline(d: DisciplineModel) {
        _uiState.update { state ->
            // Serien-Schussanzahl an neue Disziplin anpassen
            val updatedSeries = state.series.map { series ->
                SeriesUiModel(
                    shots = List(d.shotsPerSeries) { i -> series.shots.getOrElse(i) { 0 } },
                    targetImagePath = series.targetImagePath
                )
            }
            state.copy(selectedDiscipline = d, series = updatedSeries)
        }
    }

    fun updateLocation(v: String) = _uiState.update { it.copy(location = v) }
    fun updateCompetitionName(v: String) = _uiState.update { it.copy(competitionName = v) }

    // ── Serien ──────────────────────────────────────────────────────

    fun addSeries() {
        val d = _uiState.value.selectedDiscipline ?: return
        _uiState.update { it.copy(series = it.series + SeriesUiModel(List(d.shotsPerSeries) { 0 })) }
    }

    fun removeSeries(index: Int) {
        _uiState.update { state ->
            state.copy(series = state.series.toMutableList().also { it.removeAt(index) })
        }
    }

    fun updateShot(seriesIdx: Int, shotIdx: Int, rings: Int) {
        _uiState.update { state ->
            val updated = state.series.toMutableList()
            val shots = updated[seriesIdx].shots.toMutableList()
            if (shotIdx < shots.size) shots[shotIdx] = rings
            updated[seriesIdx] = updated[seriesIdx].copy(shots = shots)
            state.copy(series = updated)
        }
    }

    // ── Foto & Analyse ───────────────────────────────────────────────

    fun setAnalysisSeriesIndex(index: Int) { analysisSeriesIndex = index }

    fun onTargetImageSelected(uri: Uri) {
        val idx = analysisSeriesIndex
        if (idx >= _uiState.value.series.size) return
        _uiState.update { state ->
            val updated = state.series.toMutableList()
            updated[idx] = updated[idx].copy(targetImagePath = uri.toString())
            state.copy(series = updated)
        }
        analyzeImage(idx, uri)
    }

    fun analyzeCurrentImage(seriesIdx: Int) {
        val path = _uiState.value.series.getOrNull(seriesIdx)?.targetImagePath ?: return
        analyzeImage(seriesIdx, Uri.parse(path))
    }

    private fun analyzeImage(seriesIdx: Int, uri: Uri) {
        viewModelScope.launch {
            val disc = _uiState.value.selectedDiscipline ?: return@launch
            val bitmap = runCatching {
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
            }.getOrNull() ?: return@launch

            trainingRepo.analyzeTargetImage(bitmap, 0L, disc.maxRingsPerShot, disc.name)
                .onSuccess { analysis ->
                    _uiState.update { state ->
                        val results = state.analysisResults.toMutableMap()
                        results[seriesIdx] = analysis
                        // Schuss-Werte automatisch übernehmen wenn Anzahl passt
                        val series = if (analysis.detectedRings.size == disc.shotsPerSeries) {
                            state.series.toMutableList().also { list ->
                                list[seriesIdx] = list[seriesIdx].copy(
                                    shots = analysis.detectedRings.map { it.rings }
                                )
                            }
                        } else state.series
                        state.copy(series = series, analysisResults = results)
                    }
                }
                .onFailure { error ->
                    _uiState.update { it.copy(errorMessage = "Analyse fehlgeschlagen: ${error.message}") }
                }
        }
    }

    // ── Bedingungen ──────────────────────────────────────────────────

    fun updateWeather(v: WeatherCondition) = _uiState.update { it.copy(conditions = it.conditions.copy(weather = v)) }
    fun updateWind(v: WindCondition)       = _uiState.update { it.copy(conditions = it.conditions.copy(wind = v)) }
    fun updateFatigue(v: FatigueLevel)     = _uiState.update { it.copy(conditions = it.conditions.copy(fatigue = v)) }
    fun updateStress(v: StressLevel)       = _uiState.update { it.copy(conditions = it.conditions.copy(stress = v)) }
    fun updateEquipment(v: String)         = _uiState.update { it.copy(conditions = it.conditions.copy(equipment = v)) }
    fun updateNotes(v: String)             = _uiState.update { it.copy(notes = v) }
    fun appendNote(note: String)           = _uiState.update { state ->
        val sep = if (state.notes.isBlank()) "" else ", "
        state.copy(notes = state.notes + sep + note)
    }

    // ── Speichern ────────────────────────────────────────────────────

    fun saveSession(onSaved: () -> Unit) {
        val state = _uiState.value
        val disc = state.selectedDiscipline ?: return
        _uiState.update { it.copy(isSaving = true) }

        viewModelScope.launch {
            runCatching {
                val session = TrainingSession(
                    disciplineId = disc.id,
                    disciplineName = disc.name,
                    disciplineModel = disc,
                    mode = state.selectedMode,
                    date = LocalDateTime.now(),
                    location = state.location,
                    competitionName = state.competitionName.ifBlank { null },
                    series = state.series.mapIndexed { i, su ->
                        Series(
                            number = i + 1,
                            shots = su.shots.mapIndexed { j, rings ->
                                Shot(
                                    number = j + 1, rings = rings,
                                    zone = when {
                                        rings == disc.maxRingsPerShot -> ShotZone.BULL
                                        rings >= disc.maxRingsPerShot - 2 -> ShotZone.INNER
                                        rings >= disc.maxRingsPerShot - 5 -> ShotZone.MIDDLE
                                        rings > 0 -> ShotZone.OUTER
                                        else -> ShotZone.MISS
                                    }
                                )
                            },
                            targetImagePath = su.targetImagePath,
                            analysisResult = state.analysisResults[i]
                        )
                    },
                    conditions = state.conditions,
                    notes = state.notes
                )
                trainingRepo.saveSession(session)
                onSaved()
            }.onFailure { error ->
                _uiState.update { it.copy(isSaving = false, errorMessage = error.message) }
            }
        }
    }
}
