package com.schuetzentracker.ui.training

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.schuetzentracker.data.repository.DisciplineRepository
import com.schuetzentracker.data.repository.TrainingRepository
import com.schuetzentracker.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

@HiltViewModel
class NewTrainingViewModel @Inject constructor(
    private val trainingRepo: TrainingRepository,
    private val disciplineRepo: DisciplineRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(NewTrainingUiState())
    val uiState: StateFlow<NewTrainingUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            disciplineRepo.getAll().collect { disciplines ->
                _uiState.update { state ->
                    state.copy(
                        availableDisciplines = disciplines,
                        selectedDiscipline = state.selectedDiscipline ?: disciplines.firstOrNull()
                    )
                }
            }
        }
    }

    fun selectMode(mode: TrainingMode) = _uiState.update { it.copy(selectedMode = mode) }

    fun selectDiscipline(d: DisciplineModel) {
        _uiState.update { state ->
            val updatedSeries = state.series.map { series ->
                SeriesUiModel(shots = List(d.shotsPerSeries) { i -> series.shots.getOrElse(i) { 0 } })
            }
            state.copy(selectedDiscipline = d, series = updatedSeries)
        }
    }

    fun updateLocation(v: String)        = _uiState.update { it.copy(location = v) }
    fun updateCompetitionName(v: String) = _uiState.update { it.copy(competitionName = v) }

    fun addSeries() {
        val d = _uiState.value.selectedDiscipline ?: return
        _uiState.update { it.copy(series = it.series + SeriesUiModel(List(d.shotsPerSeries) { 0 })) }
    }

    fun removeSeries(index: Int) {
        _uiState.update { state ->
            state.copy(series = state.series.toMutableList().also { it.removeAt(index) })
        }
    }

    fun updateShot(seriesIdx: Int, shotIdx: Int, rings: Int) {
        _uiState.update { state ->
            val updated = state.series.toMutableList()
            val shots = updated[seriesIdx].shots.toMutableList()
            if (shotIdx < shots.size) shots[shotIdx] = rings
            updated[seriesIdx] = updated[seriesIdx].copy(shots = shots)
            state.copy(series = updated)
        }
    }

    fun updateWeather(v: WeatherCondition)  = _uiState.update { it.copy(conditions = it.conditions.copy(weather = v)) }
    fun updateWind(v: WindCondition)        = _uiState.update { it.copy(conditions = it.conditions.copy(wind = v)) }
    fun updateFatigue(v: FatigueLevel)      = _uiState.update { it.copy(conditions = it.conditions.copy(fatigue = v)) }
    fun updateStress(v: StressLevel)        = _uiState.update { it.copy(conditions = it.conditions.copy(stress = v)) }
    fun updateEquipment(v: String)          = _uiState.update { it.copy(conditions = it.conditions.copy(equipment = v)) }
    fun updateNotes(v: String)              = _uiState.update { it.copy(notes = v) }
    fun appendNote(note: String)            = _uiState.update { state ->
        val sep = if (state.notes.isBlank()) "" else ", "
        state.copy(notes = state.notes + sep + note)
    }
    fun dismissError() = _uiState.update { it.copy(errorMessage = null) }

    fun saveSession(onSaved: () -> Unit) {
        val state = _uiState.value
        val disc  = state.selectedDiscipline ?: return
        _uiState.update { it.copy(isSaving = true) }
        viewModelScope.launch {
            runCatching {
                val session = TrainingSession(
                    disciplineId    = disc.id,
                    disciplineName  = disc.name,
                    disciplineModel = disc,
                    mode            = state.selectedMode,
                    date            = LocalDateTime.now(),
                    location        = state.location,
                    competitionName = state.competitionName.ifBlank { null },
                    series = state.series.mapIndexed { i, su ->
                        Series(
                            number = i + 1,
                            shots  = su.shots.mapIndexed { j, rings ->
                                Shot(number = j + 1, rings = rings,
                                    zone = when {
                                        rings == disc.maxRingsPerShot     -> ShotZone.BULL
                                        rings >= disc.maxRingsPerShot - 2 -> ShotZone.INNER
                                        rings >= disc.maxRingsPerShot - 5 -> ShotZone.MIDDLE
                                        rings > 0                         -> ShotZone.OUTER
                                        else                              -> ShotZone.MISS
                                    })
                            }
                        )
                    },
                    conditions = state.conditions,
                    notes      = state.notes
                )
                trainingRepo.saveSession(session)
                onSaved()
            }.onFailure { e ->
                _uiState.update { it.copy(isSaving = false, errorMessage = "Speichern fehlgeschlagen: ${e.message}") }
            }
        }
    }
}

data class SeriesUiModel(val shots: List<Int>)

data class NewTrainingUiState(
    val selectedMode: TrainingMode = TrainingMode.TRAINING,
    val selectedDiscipline: DisciplineModel? = null,
    val availableDisciplines: List<DisciplineModel> = emptyList(),
    val location: String = "Schießstand",
    val competitionName: String = "",
    val series: List<SeriesUiModel> = emptyList(),
    val conditions: ShootingConditions = ShootingConditions(),
    val notes: String = "",
    val isSaving: Boolean = false,
    val errorMessage: String? = null
) {
    val canSave: Boolean get() =
        selectedDiscipline != null && series.isNotEmpty() && series.any { s -> s.shots.any { it > 0 } }
}
